/* Design philosophy: Moonlit Canopy — cinematic forest depth, lantern-gold focus, asymmetric composition, and calm tactile interactions. */
import { FormEvent, useState } from "react";
import { ArrowRight, Eye, EyeOff, LockKeyhole, Mail, ShieldCheck } from "lucide-react";

export default function Home() {
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);
  const [status, setStatus] = useState("");

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus("Your trail is ready. Connecting you to the canopy…");
  }

  return (
    <main className="forest-shell">
      <div className="forest-backdrop" aria-hidden="true" />
      <div className="forest-vignette" aria-hidden="true" />
      <div className="forest-mist forest-mist-one" aria-hidden="true" />
      <div className="forest-mist forest-mist-two" aria-hidden="true" />

      <header className="brand-rail">
        <div className="brand-mark-wrap">
          <img className="brand-mark" src="/manus-storage/forest-login-emblem_c151b741.png" alt="" />
        </div>
        <div className="brand-copy">
          <p className="eyebrow">The woodland realm</p>
          <p className="wordmark">Wildhaven</p>
        </div>
        <div className="rail-rule" />
        <p className="rail-note">A quiet place for brave souls.</p>
      </header>

      <section className="login-zone" aria-labelledby="login-title">
        <div className="login-card">
          <div className="card-topline"><span>01</span><span className="topline-dash" /><span>RETURNING PATHFINDER</span></div>
          <div className="heading-group">
            <p className="eyebrow accent">The wild remembers your path.</p>
            <h1 id="login-title">Enter the<br /><em>canopy.</em></h1>
            <p className="intro">Pick up where the trail went quiet. Your campfire is still burning.</p>
          </div>

          <form onSubmit={handleSubmit} className="login-form">
            <label className="field-label" htmlFor="email">Email address</label>
            <div className="input-shell">
              <Mail size={17} strokeWidth={1.7} aria-hidden="true" />
              <input id="email" name="email" type="email" placeholder="you@wildhaven.com" autoComplete="email" required />
            </div>

            <div className="password-label-row">
              <label className="field-label" htmlFor="password">Passphrase</label>
              <button className="text-button" type="button" onClick={() => setStatus("Password recovery link requested.")}>Forgot passphrase?</button>
            </div>
            <div className="input-shell">
              <LockKeyhole size={17} strokeWidth={1.7} aria-hidden="true" />
              <input id="password" name="password" type={showPassword ? "text" : "password"} placeholder="Enter your passphrase" autoComplete="current-password" required />
              <button className="icon-button" type="button" aria-label={showPassword ? "Hide passphrase" : "Show passphrase"} onClick={() => setShowPassword((value) => !value)}>
                {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
              </button>
            </div>

            <label className="remember-row">
              <input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} />
              <span className="custom-check" aria-hidden="true" />
              <span>Keep my lantern lit on this device</span>
            </label>

            <button className="submit-button" type="submit">Continue into Wildhaven <ArrowRight size={17} /></button>
            {status && <p className="status-message" role="status"><ShieldCheck size={16} />{status}</p>}
          </form>

          <div className="signup-prompt"><span>New to the realm?</span><button className="text-button signup-button" type="button" onClick={() => setStatus("Character creation is coming soon.")}>Create your path <ArrowRight size={14} /></button></div>
        </div>
      </section>

      <footer className="site-footer"><span>© 2026 Wildhaven Guild</span><span className="footer-dot">•</span><button type="button" onClick={() => setStatus("The field guide is being prepared.")}>Field guide</button><span className="footer-dot">•</span><button type="button" onClick={() => setStatus("Privacy settings are managed by the guild.")}>Privacy</button></footer>
    </main>
  );
}
