# Forest Game Login — Design Direction

## Three Initial Approaches

### Theme Name: Moonlit Canopy
Very brief intro: A cinematic night-forest interface with layered shadows, firefly accents, and a quiet sense of discovery.
Probability: 0.07

### Theme Name: Mossbound Guild
Very brief intro: A tactile woodland guild hall aesthetic using parchment, carved-wood details, and warm campfire tones.
Probability: 0.04

### Theme Name: Fern & Flint
Very brief intro: A daylight expedition style with pale sage, mineral grey, and clean trail-map geometry.
Probability: 0.02

## Chosen Approach: Moonlit Canopy

### Design Movement
Cinematic fantasy UI with editorial art direction: a restrained blend of dark-forest atmospheric realism, carved heraldic marks, and utilitarian game HUD details.

### Core Principles
1. Use layered depth instead of flat color: image, mist, grain, translucent surfaces, and fine linework.
2. Keep the login moment calm and focused; visual drama belongs to the environment, not noisy ornament.
3. Pair an expressive display face with a plain, highly legible interface sans-serif.
4. Use asymmetric composition so the forest feels expansive and the form feels intentionally placed.

### Color Philosophy
The signature color is **pine-lantern gold (#D7A85B)**: a small warm signal against cool spruce shadows, representing a safe campfire in an unknown forest. Supporting colors stay low-saturation—ink black, deep spruce, lichen green, fog grey—so the gold accent carries meaning and focus.

### Layout Paradigm
A full-bleed forest scene carries the page. The content is split into a narrow left brand rail and a right-side floating login card, leaving the middle open as atmospheric breathing room. On narrow screens, the composition collapses into a top brand mark followed by the card without losing the forest backdrop.

### Signature Elements
- A heraldic stag-and-pine emblem used as the brand anchor.
- Thin amber rules and tiny compass-like markers around headings.
- Glassy charcoal panels with subtle inner highlights, as though lit from a nearby lantern.

### Interaction Philosophy
Controls should feel like well-made field equipment: clear, tactile, and responsive. Focus states use a warm amber ring; hover states lift slightly and brighten the lantern accent. Submit feedback should feel immediate without distracting animation.

### Animation
Reveal the forest and brand rail with a gentle opacity/translate entrance. Stagger the login card, heading, fields, and button by roughly 50ms. Use short ease-out transitions for input focus and button hover. Add a barely perceptible drift to the mist layer only when reduced motion is not requested.

### Typography System
Display: **DM Serif Display**, used for the title and one short evocative phrase. Interface: **Manrope**, used for labels, helper text, navigation, and buttons. The display face should feel like a carved storybook title; the sans should feel modern and trustworthy.

### Brand Essence
A quiet gateway into a dangerous, beautiful world for players who prefer atmosphere and discovery over noise. Personality: **watchful, crafted, inviting**.

### Brand Voice
Headlines are evocative but concise. CTAs are direct and active. Microcopy sounds like a companion preparing you for the trail.

Example lines:
- “The wild remembers your path.”
- “Step back into the canopy.”

### Wordmark & Logo
The mark is a geometric stag antler enclosing a small pine and crescent moon, rendered like a carved guild seal. The wordmark uses small caps with generous tracking rather than a default gaming logotype.

### Signature Brand Color
**Pine-lantern gold — #D7A85B.**
