// routes/market.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

const requireAuth = (req, res, next) => {
    if (!req.session || !req.session.user) {
        return res.status(401).json({ message: 'Unauthorized. Please login.' });
    }
    next();
};

// GET USER INVENTORY
router.get('/my-inventory', requireAuth, async (req, res) => {
    const userId = req.session.user.id;
    try {
        const result = await db.query(
            'SELECT * FROM animals WHERE owner_id = $1 AND is_for_trade = FALSE ORDER BY created_at DESC',
            [userId]
        );
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error sa pagkuha ng inventory.' });
    }
});

// GET MARKET LISTINGS
router.get('/', async (req, res) => {
    try {
        const query = `
            SELECT trades.id AS trade_id, trades.price, animals.species, animals.rarity, animals.level, users.username AS seller
            FROM trades
            JOIN animals ON trades.animal_id = animals.id
            JOIN users ON trades.seller_id = users.id
            WHERE trades.status = 'ACTIVE'
            ORDER BY trades.created_at DESC
        `;
        const result = await db.query(query);
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error sa pagkuha ng market items.' });
    }
});

module.exports = router;