// routes/user.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// MIDDLEWARE: AUTHENTICATION CHECK
const requireAuth = (req, res, next) => {
    if (!req.session || !req.session.user) {
        return res.status(401).json({ message: 'Unauthorized' });
    }
    next();
};

// 1. GET USER PROFILE
router.get('/profile/:id', requireAuth, async (req, res) => {
    try {
        const userRes = await db.query(
            'SELECT id, username, email, coins, bio, avatar, created_at FROM users WHERE id = $1',
            [req.params.id]
        );
        if (userRes.rows.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        const animalsRes = await db.query(
            'SELECT COUNT(*) FROM animals WHERE owner_id = $1',
            [req.params.id]
        );

        res.json({
            user: userRes.rows[0],
            animalCount: parseInt(animalsRes.rows[0].count, 10) || 0
        });
    } catch (err) {
        console.error('Database Error on Get Profile:', err);
        res.status(500).json({ message: 'Error fetching profile' });
    }
});

// 2. UPDATE BIO
router.put('/profile', requireAuth, async (req, res) => {
    const { bio } = req.body;
    try {
        await db.query('UPDATE users SET bio = $1 WHERE id = $2', [bio, req.session.user.id]);
        res.json({ message: 'Profile updated successfully' });
    } catch (err) {
        console.error('Database Error on Update Bio:', err);
        res.status(500).json({ message: 'Error updating profile' });
    }
});

// 3. UPDATE AVATAR / ICON
router.put('/avatar', requireAuth, async (req, res) => {
    const { avatar } = req.body;

    if (!avatar) {
        return res.status(400).json({ message: 'Avatar icon is required' });
    }

    try {
        const userId = req.session.user.id;

        // Update database
        await db.query('UPDATE users SET avatar = $1 WHERE id = $2', [avatar, userId]);

        // Update active session data
        if (req.session.user) {
            req.session.user.avatar = avatar;
        }

        return res.json({ message: 'Avatar updated successfully', avatar });
    } catch (err) {
        console.error('Database Error on Update Avatar:', err);
        return res.status(500).json({ message: 'Error updating avatar in database' });
    }
});

// 4. SEND PRIVATE MESSAGE
router.post('/messages/send', requireAuth, async (req, res) => {
    const { receiver_id, message } = req.body;
    const sender_id = req.session.user.id;

    if (!message || !receiver_id) {
        return res.status(400).json({ message: 'Missing fields' });
    }

    try {
        const newMsg = await db.query(
            'INSERT INTO private_messages (sender_id, receiver_id, message) VALUES ($1, $2, $3) RETURNING *',
            [sender_id, receiver_id, message]
        );
        res.json(newMsg.rows[0]);
    } catch (err) {
        console.error('Database Error on Send Private Message:', err);
        res.status(500).json({ message: 'Error sending message' });
    }
});

// 5. GET PRIVATE MESSAGES WITH A SPECIFIC USER
router.get('/messages/:otherUserId', requireAuth, async (req, res) => {
    const currentUserId = req.session.user.id;
    const otherUserId = req.params.otherUserId;

    try {
        const query = `
            SELECT pm.*, u.username AS sender_name 
            FROM private_messages pm
            JOIN users u ON pm.sender_id = u.id
            WHERE (pm.sender_id = $1 AND pm.receiver_id = $2)
               OR (pm.sender_id = $2 AND pm.receiver_id = $1)
            ORDER BY pm.created_at ASC
        `;
        const result = await db.query(query, [currentUserId, otherUserId]);
        res.json(result.rows);
    } catch (err) {
        console.error('Database Error on Fetch Conversation:', err);
        res.status(500).json({ message: 'Error fetching conversation' });
    }
});

module.exports = router;