// routes/news.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// READ-ONLY NEWS FOR PLAYERS
router.get('/', async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM news ORDER BY created_at DESC');
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error fetching news.' });
    }
});

module.exports = router;