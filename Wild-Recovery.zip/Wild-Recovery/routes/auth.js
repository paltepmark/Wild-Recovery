// routes/auth.js
const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const db = require('../config/db');

// REGISTER / SIGN UP
router.post('/signup', async (req, res) => {
    const { username, email, password } = req.body;

    try {
        const userCheck = await db.query('SELECT * FROM users WHERE email = $1 OR username = $2', [email, username]);
        if (userCheck.rows.length > 0) {
            return res.status(400).json({ message: 'Username or Email already exists!' });
        }

        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        const newUser = await db.query(
            'INSERT INTO users (username, email, password_hash) VALUES ($1, $2, $3) RETURNING id, username, email, coins, avatar',
            [username, email, hashedPassword]
        );

        res.status(201).json({ message: 'User registered successfully!', user: newUser.rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error during registration.' });
    }
});

// LOGIN / SIGN IN
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const result = await db.query('SELECT * FROM users WHERE email = $1', [email]);
        if (result.rows.length === 0) {
            return res.status(400).json({ message: 'Invalid Email or Password!' });
        }

        const user = result.rows[0];

        const isMatch = await bcrypt.compare(password, user.password_hash);
        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid Email or Password!' });
        }

        req.session.user = {
            id: user.id,
            username: user.username,
            email: user.email,
            coins: user.coins,
            avatar: user.avatar || '🌲'
        };

        res.json({ message: 'Login successful!', user: req.session.user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error during login.' });
    }
});

// GET CURRENT SESSION USER (Laging binabasa mula sa DB para Updated ang Avatar)
router.get('/me', async (req, res) => {
    if (!req.session || !req.session.user) {
        return res.status(401).json({ message: 'Not authenticated' });
    }

    try {
        const result = await db.query(
            'SELECT id, username, email, coins, avatar FROM users WHERE id = $1',
            [req.session.user.id]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        const updatedUser = result.rows[0];
        req.session.user.avatar = updatedUser.avatar; // I-sync sa session

        res.json({ user: updatedUser });
    } catch (err) {
        console.error('Error fetching session user:', err);
        res.status(500).json({ message: 'Server error fetching user session.' });
    }
});

// LOGOUT
router.get('/logout', (req, res) => {
    req.session.destroy(() => {
        res.redirect('/login');
    });
});

module.exports = router;