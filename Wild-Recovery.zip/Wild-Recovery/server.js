// server.js
const express = require('express');
const session = require('express-session');
const path = require('path');
const dotenv = require('dotenv');
const http = require('http');
const { Server } = require('socket.io');
const db = require('./config/db');

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

const sessionMiddleware = session({
    secret: 'wild_recovery_forest_secret_key',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 3600000 }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(sessionMiddleware);

io.use((socket, next) => {
    sessionMiddleware(socket.request, {}, next);
});

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/market', require('./routes/market'));
app.use('/api/news', require('./routes/news'));
app.use('/api/user', require('./routes/user'));
// server.js
const userRoutes = require('./routes/user');

// Tiyaking nakalagay ito:
app.use('/api/user', userRoutes);

// Views
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'login.html'));
});

app.get('/dashboard', (req, res) => {
    if (!req.session || !req.session.user) {
        return res.redirect('/login');
    }
    res.sendFile(path.join(__dirname, 'views', 'dashboard.html'));
});

app.get('/', (req, res) => {
    res.redirect('/login');
});

// Socket.io Global Chat
io.on('connection', async (socket) => {
    try {
        const history = await db.query(`
            SELECT global_chat.id, global_chat.message, global_chat.created_at, users.username 
            FROM global_chat 
            JOIN users ON global_chat.user_id = users.id 
            ORDER BY global_chat.created_at ASC LIMIT 30
        `);
        socket.emit('chat_history', history.rows);
    } catch (err) {
        console.error('Error fetching chat history:', err);
    }

    socket.on('send_chat', async (data) => {
        const sessionUser = socket.request.session ? socket.request.session.user : null;
        if (!sessionUser) return;

        try {
            await db.query(
                'INSERT INTO global_chat (user_id, message) VALUES ($1, $2)',
                [sessionUser.id, data.message]
            );

            io.emit('receive_chat', {
                username: sessionUser.username,
                message: data.message,
                timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            });
        } catch (err) {
            console.error('Error saving chat message:', err);
        }
    });
});

server.listen(PORT, () => {
    console.log(`🌲 Wild Recovery Server running at http://localhost:${PORT}`);
});