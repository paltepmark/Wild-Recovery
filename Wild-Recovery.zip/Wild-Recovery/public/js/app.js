const socket = io();
let allMarketItems = [];


document.addEventListener('DOMContentLoaded', () => {
    checkUserSession();
    loadNewsFeed();
    loadMarketListings();

    socket.on('chat_history', (messages) => {
        const chatBox = document.getElementById('chat-messages');
        if (!chatBox) return;
        chatBox.innerHTML = '';
        messages.forEach(msg => appendChatMessage(msg.username, msg.message, new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })));
    });

    socket.on('receive_chat', (data) => {
        appendChatMessage(data.username, data.message, data.timestamp);
    });
});


function appendChatMessage(username, message, time) {
    const chatBox = document.getElementById('chat-messages');
    if (chatBox) {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'chat-msg';
        msgDiv.innerHTML = `<strong>[${escapeHTML(username)}]</strong> <span class="chat-time">(${time})</span>: ${escapeHTML(message)}`;
        chatBox.appendChild(msgDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}

function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    if (message !== '') {
        socket.emit('send_chat', { message });
        input.value = '';
    }
}

function escapeHTML(str) {
    return String(str).replace(/[&<>'"]/g, tag => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    }[tag] || tag));
}


function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));

    const target = document.getElementById(`section-${tabName}`);
    if (target) target.classList.remove('hidden');

    if (window.event && window.event.currentTarget) {
        window.event.currentTarget.classList.add('active');
    }

    if (tabName === 'market') loadMarketListings();
    if (tabName === 'news') loadNewsFeed();
    if (tabName === 'inventory') loadUserInventory();
    if (tabName === 'profile') loadMyProfile();
}


function calculateTitle(animalCount) {
    const count = Number(animalCount) || 0;

    if (count >= 100) return { title: 'Apex Predator', color: '#8e44ad' };
    if (count >= 75)  return { title: 'Master Ranger', color: '#c0392b' };
    if (count >= 50)  return { title: 'Legendary Tracker', color: '#e74c3c' };
    if (count >= 30)  return { title: 'Pro Hunter', color: '#2980b9' };
    if (count >= 15)  return { title: 'Veteran Rescuer', color: '#27ae60' };
    if (count >= 5)   return { title: 'Forest Trapper', color: '#d35400' };
    return { title: 'Novice Trapper', color: '#7f8c8d' };
}

function updateSidebarTitle(titleInfo) {
    const sidebarTitleTag = document.getElementById('user-sidebar-title');
    if (sidebarTitleTag) {
        sidebarTitleTag.innerText = titleInfo.title;
        sidebarTitleTag.style.backgroundColor = titleInfo.color;
        sidebarTitleTag.style.color = '#ffffff';
        sidebarTitleTag.style.padding = '2px 8px';
        sidebarTitleTag.style.borderRadius = '6px';
        sidebarTitleTag.style.fontSize = '12px';
    }
}


async function checkUserSession() {
    try {
        const res = await fetch('/api/auth/me');
        if (res.ok) {
            const data = await res.json();
            const user = data.user || data;

            
            if (user.avatar) {
                localStorage.setItem('user_avatar', user.avatar);
                const sidebarAvatar = document.getElementById('user-display-avatar');
                const profileAvatar = document.getElementById('profile-avatar-display');
                if (sidebarAvatar) sidebarAvatar.innerText = user.avatar;
                if (profileAvatar) profileAvatar.innerText = user.avatar;
            }

            
            if (user.username) {
                localStorage.setItem('user_name', user.username);
                const sidebarName = document.getElementById('user-display-name');
                const profileName = document.getElementById('profile-username');
                if (sidebarName) sidebarName.innerText = user.username;
                if (profileName) profileName.innerText = user.username;
            }

            
            const coinsDisplay = document.getElementById('stat-coins');
            if (coinsDisplay && user.coins !== undefined) {
                coinsDisplay.innerText = `${user.coins} 🪙`;
            }
        }
    } catch (err) {
        console.error('Session error:', err);
    }
}


async function loadMyProfile() {
    try {
        const meRes = await fetch('/api/auth/me');
        if (!meRes.ok) return;
        const meData = await meRes.json();
        const user = meData.user || meData;

        const profileRes = await fetch(`/api/user/profile/${user.id}`);
        if (!profileRes.ok) return;
        const data = await profileRes.json();

        const animalCount = data.animalCount || 0;
        const titleInfo = calculateTitle(animalCount);

        const profileUsername = document.getElementById('profile-username');
        const sidebarName = document.getElementById('user-display-name');
        if (profileUsername) profileUsername.innerText = data.user.username;
        if (sidebarName) sidebarName.innerText = data.user.username;

        document.getElementById('profile-user-id').innerText = data.user.id || '';
        document.getElementById('profile-email').innerText = data.user.email || '';
        document.getElementById('profile-animals').innerText = animalCount;
        document.getElementById('profile-bio-input').value = data.user.bio || '';

        const profileAvatar = document.getElementById('profile-avatar-display');
        const sidebarAvatar = document.getElementById('user-display-avatar');
        if (profileAvatar) profileAvatar.innerText = data.user.avatar || '🌲';
        if (sidebarAvatar) sidebarAvatar.innerText = data.user.avatar || '🌲';

        const profileTitleTag = document.getElementById('profile-user-title');
        if (profileTitleTag) {
            profileTitleTag.innerText = titleInfo.title;
            profileTitleTag.style.backgroundColor = titleInfo.color;
        }

        updateSidebarTitle(titleInfo);

    } catch (err) {
        console.error('Error loading profile:', err);
    }
}

async function updateProfileBio() {
    const bio = document.getElementById('profile-bio-input').value;
    try {
        const res = await fetch('/api/user/profile', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ bio })
        });
        if (res.ok) {
            alert('Bio updated successfully!');
        } else {
            alert('Failed to update bio.');
        }
    } catch (err) {
        console.error('Error updating bio:', err);
    }
}


function openAvatarModal() {
    const modal = document.getElementById('avatar-modal');
    if (modal) modal.classList.remove('hidden');
}

function closeAvatarModal() {
    const modal = document.getElementById('avatar-modal');
    if (modal) modal.classList.add('hidden');
}

async function selectAvatar(selectedIcon) {
    try {
        const res = await fetch('/api/user/avatar', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ avatar: selectedIcon })
        });

        if (res.ok) {
            localStorage.setItem('user_avatar', selectedIcon);

            const sidebarAvatar = document.getElementById('user-display-avatar');
            const profileAvatar = document.getElementById('profile-avatar-display');
            if (sidebarAvatar) sidebarAvatar.innerText = selectedIcon;
            if (profileAvatar) profileAvatar.innerText = selectedIcon;

            closeAvatarModal();
        } else {
            alert('Failed to save avatar!');
        }
    } catch (err) {
        console.error('Error changing avatar:', err);
    }
}


async function loadPrivateChat() {
    const targetUserId = document.getElementById('dm-target-id').value;
    if (!targetUserId) return alert('Paki-lagay ang User ID ng kakausapin.');

    try {
        const res = await fetch(`/api/user/messages/${targetUserId}`);
        const messages = await res.json();

        const chatBox = document.getElementById('private-chat-messages');
        chatBox.innerHTML = '';

        if (!Array.isArray(messages) || messages.length === 0) {
            chatBox.innerHTML = '<p style="color:#888; text-align:center;">No previous messages with this user.</p>';
            return;
        }

        messages.forEach(msg => {
            const msgDiv = document.createElement('div');
            msgDiv.className = 'chat-msg';
            msgDiv.innerHTML = `<strong>[${escapeHTML(msg.sender_name)}]</strong>: ${escapeHTML(msg.message)}`;
            chatBox.appendChild(msgDiv);
        });
        chatBox.scrollTop = chatBox.scrollHeight;
    } catch (err) {
        console.error('Error loading private messages:', err);
    }
}

async function sendPrivateMessage() {
    const targetUserId = document.getElementById('dm-target-id').value;
    const message = document.getElementById('private-chat-input').value.trim();

    if (!targetUserId || !message) return alert('Kailangan ng Target User ID at mensahe!');

    try {
        const res = await fetch('/api/user/messages/send', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ receiver_id: targetUserId, message })
        });

        if (res.ok) {
            document.getElementById('private-chat-input').value = '';
            loadPrivateChat();
        }
    } catch (err) {
        console.error('Error sending DM:', err);
    }
}


async function loadNewsFeed() {
    try {
        const res = await fetch('/api/news');
        const news = await res.json();
        const container = document.getElementById('news-feed-container');

        if (!Array.isArray(news) || news.length === 0) {
            container.innerHTML = '<p style="color:#888;">No news announcements right now.</p>';
            return;
        }

        container.innerHTML = news.map(item => `
            <div class="info-card" style="margin-bottom: 15px;">
                <div class="card-icon"><i class="fa-solid fa-scroll"></i></div>
                <div style="flex-grow: 1;">
                    <span class="badge">${escapeHTML(item.badge)}</span>
                    <h3>${escapeHTML(item.title)}</h3>
                    <p>${escapeHTML(item.content)}</p>
                </div>
            </div>
        `).join('');
    } catch (err) {
        console.error('Error loading news:', err);
    }
}


async function loadUserInventory() {
    const container = document.getElementById('inventory-items-container');
    if (!container) return;

    try {
        const res = await fetch('/api/market/my-inventory');
        const animals = await res.json();

        if (!Array.isArray(animals) || animals.length === 0) {
            container.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: #888;">You have no animals in your inventory.</p>';
            return;
        }

        const iconsMap = { 'Bear': '🐻', 'Wolf': '🐺', 'Fox': '🦊', 'Lynx': '🐱', 'Deer': '🦌', 'Eagle': '🦅' };

        container.innerHTML = animals.map(item => {
            const icon = iconsMap[item.species] || '🐾';
            const rarityClass = `rarity-${item.rarity.toLowerCase()}`;

            return `
                <div class="animal-card ${rarityClass}">
                    <span class="rarity-badge ${rarityClass}">${item.rarity}</span>
                    <div class="animal-icon">${icon}</div>
                    <div>
                        <h3>${escapeHTML(item.species)}</h3>
                        <p>Level ${item.level}</p>
                    </div>
                </div>
            `;
        }).join('');
    } catch (err) {
        console.error('Error loading inventory:', err);
    }
}


async function loadMarketListings() {
    try {
        const res = await fetch('/api/market');
        allMarketItems = await res.json();
        renderMarketGrid(allMarketItems);
    } catch (err) {
        console.error('Error fetching market:', err);
    }
}

function renderMarketGrid(items) {
    const container = document.getElementById('market-items-container');
    if (!container) return;

    if (!Array.isArray(items) || items.length === 0) {
        container.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: #888;">No animals found in the market.</p>';
        return;
    }

    const iconsMap = { 'Bear': '🐻', 'Wolf': '🐺', 'Fox': '🦊', 'Lynx': '🐱', 'Deer': '🦌', 'Eagle': '🦅' };

    container.innerHTML = items.map(item => {
        const icon = iconsMap[item.species] || '🐾';
        const rarityClass = `rarity-${item.rarity.toLowerCase()}`;

        return `
            <div class="animal-card ${rarityClass}">
                <span class="rarity-badge ${rarityClass}">${item.rarity}</span>
                <div class="animal-icon">${icon}</div>
                <div>
                    <h3>${escapeHTML(item.species)}</h3>
                    <p>Level ${item.level} | Seller: <strong>${escapeHTML(item.seller)}</strong></p>
                </div>
                <div>
                    <div class="price">🪙 ${item.price} Coins</div>
                    <button class="btn-buy" onclick="buyAnimal(${item.trade_id})">Buy Animal</button>
                </div>
            </div>
        `;
    }).join('');
}

function filterMarket() {
    const searchVal = document.getElementById('search-animal').value.toLowerCase();
    const rarityVal = document.getElementById('filter-rarity').value;

    const filtered = allMarketItems.filter(item => {
        const matchesSearch = item.species.toLowerCase().includes(searchVal);
        const matchesRarity = (rarityVal === 'ALL') || (item.rarity.toUpperCase() === rarityVal);
        return matchesSearch && matchesRarity;
    });

    renderMarketGrid(filtered);
}